--------------------------------------------------------
--  Please run with SBREXT account if it is run directly
--------------------------------------------------------

@gf32649_SBREXT_SET_ROW_BODY_NCIP.sql
