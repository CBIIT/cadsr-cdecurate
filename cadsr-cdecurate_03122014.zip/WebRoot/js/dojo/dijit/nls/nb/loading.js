({
	loadingState: "Laster inn...",
	errorState: "Det oppsto en feil"
})
