({
		previousMessage: "Előző menüpontok",
		nextMessage: "További menüpontok"
})
