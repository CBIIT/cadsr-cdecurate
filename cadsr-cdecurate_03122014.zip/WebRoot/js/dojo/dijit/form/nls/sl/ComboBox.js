({
		previousMessage: "Prejšnje možnosti",
		nextMessage: "Dodatne možnosti"
})

