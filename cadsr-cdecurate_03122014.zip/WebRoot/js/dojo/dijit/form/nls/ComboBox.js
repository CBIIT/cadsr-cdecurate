({
		previousMessage: "Previous choices",
		nextMessage: "More choices"
})
