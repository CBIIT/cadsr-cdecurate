dojo.provide("dijit.form.ToggleButton");
dojo.require("dijit.form.Button");
